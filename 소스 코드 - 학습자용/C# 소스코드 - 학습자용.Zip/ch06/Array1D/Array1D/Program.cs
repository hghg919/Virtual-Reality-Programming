﻿// See https://aka.ms/new-console-template for more information
int[] a = { -1, 0, 1, 2, 3 };
foreach (int cnt in a)
{
    Console.Write(cnt + " ");
}