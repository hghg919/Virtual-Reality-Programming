﻿// See https://aka.ms/new-console-template for more information
Random r = new Random();

Console.WriteLine(r.NextDouble());
Console.WriteLine(r.NextDouble() * 10);
Console.WriteLine(r.NextDouble() * 20);