﻿// See https://aka.ms/new-console-template for more information
var a = 88.99;
var b = 'A';
var c = "space";

Console.WriteLine(a.GetType());
Console.WriteLine(b.GetType());
Console.WriteLine(c.GetType());