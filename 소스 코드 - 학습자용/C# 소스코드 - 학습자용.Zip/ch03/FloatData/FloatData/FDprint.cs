﻿// See https://aka.ms/new-console-template for more information
float a, b, result1;
a = 2;
b = 3;
result1 = a / b;

double c, d, result2;
c = 2;
d = 3;
result2 = c / d;

Console.WriteLine("float = " + result1);
Console.WriteLine("double = " + result2);