﻿// See https://aka.ms/new-console-template for more information
float a;

Console.Write("1. 실수 입력 : ");
a = float.Parse(Console.ReadLine());

Console.WriteLine("2. 입력한 실수값 출력 : " + a);