﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("short 형식\t : " + sizeof(short) + " 바이트");
Console.WriteLine("int 형식\t : " + sizeof(int) + " 바이트");
Console.WriteLine("long 형식\t : " + sizeof(long) + " 바이트");
Console.WriteLine("float 형식\t : " + sizeof(float) + " 바이트");
Console.WriteLine("double 형식\t : " + sizeof(double) + " 바이트");
Console.WriteLine("char 형식\t : " + sizeof(char) + " 바이트");
Console.WriteLine("bool 형식\t : " + sizeof(bool) + " 바이트");