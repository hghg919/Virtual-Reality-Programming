﻿// See https://aka.ms/new-console-template for more information
string fruit = "과일 → ";

Console.WriteLine("주어진 문자열 : " + fruit);

fruit += " 사과 ";
Console.WriteLine("1.문자열 추가 : " + fruit);

fruit += " 바나나 ";
Console.WriteLine("2.문자열 추가 : " + fruit);