﻿// See https://aka.ms/new-console-template for more information
int a = 123;
long b = 1234567890123456;

// 변수에 대한 자료형 검사
Console.WriteLine(a.GetType());
Console.WriteLine(b.GetType());

// 상수에 대한 자료형 검사
Console.WriteLine(38.277f.GetType());
Console.WriteLine(38.277.GetType());
Console.WriteLine(38.277m.GetType());
Console.WriteLine("스페이스".GetType());
Console.WriteLine('A'.GetType());