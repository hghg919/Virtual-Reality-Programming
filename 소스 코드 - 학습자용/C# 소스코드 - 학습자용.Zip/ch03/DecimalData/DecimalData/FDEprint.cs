﻿// See https://aka.ms/new-console-template for more information
decimal a, b;
a = 0.123456789012345678901234567890123m;  // 숫자 뒤에 m을 반드시 첨부
b = 3.141592653589793238462643383279502884197m;

Console.WriteLine("decimal = " + a);
Console.WriteLine("decimal = " + b);