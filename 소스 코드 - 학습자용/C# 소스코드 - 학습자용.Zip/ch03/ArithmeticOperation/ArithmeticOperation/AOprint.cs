﻿// See https://aka.ms/new-console-template for more information
int a, b, hap, cha, gob, na;
a = 10;
b = 20;

hap = a + b;
cha = a - b;
gob = a * b;
na = a / b;

Console.WriteLine("a=10, b=20일 때, 사칙 연산 결과");
Console.WriteLine("a + b = " + hap);
Console.WriteLine("a - b = " + cha);
Console.WriteLine("a * b = " + gob);
Console.WriteLine("a / b = " + na);