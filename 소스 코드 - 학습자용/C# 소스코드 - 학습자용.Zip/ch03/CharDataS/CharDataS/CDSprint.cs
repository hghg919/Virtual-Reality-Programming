﻿// See https://aka.ms/new-console-template for more information
char a = '푸';
char b = '른';
char c = '하';
char d = '늘';

Console.Write(a);
Console.Write(b);
Console.WriteLine();  // 강제 줄 바꿈
Console.Write(c);
Console.Write(d);