﻿// See https://aka.ms/new-console-template for more information
string a, b, c;

a = "Space Zone";
b = a.ToUpper();  // 모두 대문자로 변환
c = a.ToLower();  // 모두 소문자로 변환

Console.WriteLine("주어진 문자열 : " + a);
Console.WriteLine(" > 대문자로 변환 : " +b);
Console.WriteLine(" > 소문자로 변환 : " + c);