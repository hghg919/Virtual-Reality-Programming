﻿// See https://aka.ms/new-console-template for more information
string a = "오늘은";
string b = "어제 죽어간 이가";
string c = "그토록 기다리던 내일이다.";

Console.WriteLine(a);
Console.WriteLine(b);
Console.WriteLine(c);