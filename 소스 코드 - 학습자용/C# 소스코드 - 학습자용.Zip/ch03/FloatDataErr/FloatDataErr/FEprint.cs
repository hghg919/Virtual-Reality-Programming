﻿// See https://aka.ms/new-console-template for more information
float a, b, result1;
double result2;

a = 2;
b = 3;
result1 = a / b;
result2 = a / b;

Console.WriteLine("float = " + result1);
Console.WriteLine("double = " + result2);