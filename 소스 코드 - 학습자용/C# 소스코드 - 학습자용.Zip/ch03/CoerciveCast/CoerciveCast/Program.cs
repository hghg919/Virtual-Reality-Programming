﻿// See https://aka.ms/new-console-template for more information
int a;
float b, c;

a = 10;
b = 3.5f;
c = a / b;

Console.WriteLine("a : " + a + " → " + a.GetType());
Console.WriteLine("b : " + b + " → " + b.GetType());
Console.WriteLine("c : " + c + " → " + c.GetType());