﻿// See https://aka.ms/new-console-template for more information
string a = "프로그래밍";

Console.WriteLine(a + "!");
Console.WriteLine(a[1]);
Console.WriteLine(a[4]);