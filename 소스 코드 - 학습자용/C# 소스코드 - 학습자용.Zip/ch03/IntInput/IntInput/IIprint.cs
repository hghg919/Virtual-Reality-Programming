﻿// See https://aka.ms/new-console-template for more information
int a;

Console.Write("1. 정수 입력 : ");
a = int.Parse(Console.ReadLine());

Console.WriteLine("2. 입력한 정수값 출력 : " + a);