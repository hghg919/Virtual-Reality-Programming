﻿// See https://aka.ms/new-console-template for more information
string s;

Console.Write("1. 문자열 입력 : ");
s = Console.ReadLine();

Console.WriteLine("2. 입력한 문자열 출력 : " + s);