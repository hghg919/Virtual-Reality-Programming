﻿// See https://aka.ms/new-console-template for more information
int a, b, c, result;
a = 10;
b = 2;

result = a % b;

Console.WriteLine("a = 10, b = 2 일 때, 나머지 연산 결과");
Console.WriteLine("a % b = " + result);