﻿// See https://aka.ms/new-console-template for more information
bool a = 20 < 30;
bool b = 50 >= 80;
bool c = !(37 == 88);

Console.WriteLine("20 < 30 : " + a);
Console.WriteLine("50 >= 80 : " + b);
Console.WriteLine("!(37 == 88) : " + c);
Console.WriteLine(sizeof(bool));