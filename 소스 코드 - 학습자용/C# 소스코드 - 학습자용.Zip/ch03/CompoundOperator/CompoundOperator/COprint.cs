﻿// See https://aka.ms/new-console-template for more information
int count = 100;

Console.WriteLine("주어진 데이터값이 count = 100 일 때");
count += 5;   // count = count + 5
Console.WriteLine("count += 5 : " + count);

count -= 3;   // count = count - 3
Console.WriteLine("count -= 3 : " + count);

count *= 2;   // count = count * 2
Console.WriteLine("count *= 2 : " + count);

count /= 10;   // count = count / 10
Console.WriteLine("count /= 10 : " + count);