﻿// See https://aka.ms/new-console-template for more information
Console.Write("참 : ");
Console.WriteLine(true);
Console.Write("거짓 : ");
Console.WriteLine(false);
