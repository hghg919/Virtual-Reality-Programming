﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("대한민국"[0]);
Console.WriteLine("대한민국"[1]);
Console.WriteLine("대한민국"[2]);
Console.WriteLine("대한민국"[3]);