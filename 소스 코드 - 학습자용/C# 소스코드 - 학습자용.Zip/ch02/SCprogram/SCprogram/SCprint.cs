﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("대" + "한" + "민국");
Console.WriteLine("자축인묘" + "진사오" + "미신유술해");