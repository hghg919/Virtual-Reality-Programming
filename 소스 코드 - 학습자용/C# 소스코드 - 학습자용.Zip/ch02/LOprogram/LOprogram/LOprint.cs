﻿// See https://aka.ms/new-console-template for more information
Console.Write("!false의 논리 연산 결과 : ");
Console.WriteLine(!false);
Console.Write("true || false의 논리 연산 결과 : ");
Console.WriteLine(true || false);
Console.Write("true && false의 논리 연산 결과 : ");
Console.WriteLine(true && false);