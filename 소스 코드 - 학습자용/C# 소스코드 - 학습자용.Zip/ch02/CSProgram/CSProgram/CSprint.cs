﻿// See https://aka.ms/new-console-template for more information
    Console.Write("문자 출력 : ");
    Console.WriteLine('A');
    Console.Write("문자열 출력 : ");
    Console.WriteLine("반갑습니다.");