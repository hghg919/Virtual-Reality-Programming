﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("대한\t민국");
Console.WriteLine("용기는 \'진실\'에서 우러나온다.");
Console.WriteLine("오늘보다\n내일은 희망차다.");
