﻿// See https://aka.ms/new-console-template for more information
Console.Write("88 > 99의 비교 연산 결과 : ");
Console.WriteLine(88 > 99);
Console.Write("88 <= 99의 비교 연산 결과 : ");
Console.WriteLine(88 <= 99);