﻿// See https://aka.ms/new-console-template for more information
class Solution
{
    static void Main(string[] args)
    {
        Console.Write(" > -35의 Math.Abs : ");
        Console.WriteLine(Math.Abs(-35));

        Console.Write(" > (10, 20)의 Math.Max : ");
        Console.WriteLine(Math.Max(10, 20));

        Console.Write(" > (200, 300)의 Math.Min : ");
        Console.WriteLine(Math.Min(200, 300));

        Console.Write(" > 23.5789의 Math.Round : ");
        Console.WriteLine(Math.Round(23.5789));

        Console.Write(" > 53.9563의 Math.Ceiling : ");
        Console.WriteLine(Math.Ceiling(53.9563));

        Console.Write(" > 53.9563의 Math.Floor : ");
        Console.WriteLine(Math.Floor(53.9563));
    }
}