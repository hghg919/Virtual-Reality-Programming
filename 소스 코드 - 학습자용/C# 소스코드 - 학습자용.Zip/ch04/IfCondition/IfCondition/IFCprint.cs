﻿// See https://aka.ms/new-console-template for more information
int a;

Console.Write("정수 입력 : ");
a = int.Parse(Console.ReadLine());

if(a > 0)
{
    Console.WriteLine("양의 정수입니다.");
}